import { Component } from '@angular/core';
import { LoadingService } from './loading.service';
import { RouterModule } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  standalone: true,
  imports: [CommonModule, RouterModule, HeaderComponent, MatProgressSpinnerModule]
})
export class AppComponent {
  title = 'angular-quiz';
  loading$ = this.loadingService.loading$;

  constructor(private loadingService: LoadingService) {}
}
