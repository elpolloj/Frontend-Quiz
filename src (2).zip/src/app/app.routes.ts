import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { UserListComponent } from './user-list/user-list.component';
import { UserDetailComponent } from './user-detail/user-detail.component';

export const ROUTES: Routes = [
  { path: '', component: HomeComponent, data: { animation: 'HomePage' } },
  { path: 'users', component: UserListComponent, data: { animation: 'UserListPage' } },
  { path: 'user/:id', component: UserDetailComponent, data: { animation: 'UserDetailPage' } }
];
